<?php


date_default_timezone_set('UTC');

require __DIR__.'/../bootstrap.php';