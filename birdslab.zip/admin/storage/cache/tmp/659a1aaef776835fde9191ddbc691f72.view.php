<?php echo  $app->assets(['addons:assets/addons.js','addons:assets/js/index.js'], $app['cockpit/version']) ; ?>


<h1><a href="<?php $app->route('/settingspage'); ?>"><?php echo $app("i18n")->get('Settings'); ?></a> / <?php echo $app("i18n")->get('Addons'); ?></h1>

<div data-ng-controller="addons">


    <?php if(count($addons)) { ?>

        <table class="uk-table">
            <tbody>
                <?php foreach($addons as $addon) { ?>
                <tr>
                    <td><?php echo  $addon ; ?></td>
                </tr>
                <?php } ?>
            </tbody>
        </table>

    <?php }else{ ?>

        <div class="uk-alert">
            <?php echo $app("i18n")->get('No additional addons installed.'); ?>
        </div>

    <?php } ?>


</div>
